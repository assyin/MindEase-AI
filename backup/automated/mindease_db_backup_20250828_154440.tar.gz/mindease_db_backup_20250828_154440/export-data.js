const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

// Configuration Supabase
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function exportData() {
    const backupData = {
        timestamp: new Date().toISOString(),
        tables: {}
    };

    const tables = [
        'conversations',
        'messages', 
        'ai_contexts',
        'conversation_summaries',
        'user_profiles',
        'sessions',
        'mood_entries',
        'user_goals'
    ];

    console.log('🔄 Début de l\'export des données...');

    for (const table of tables) {
        try {
            console.log(`📋 Export de la table: ${table}`);
            const { data, error } = await supabase
                .from(table)
                .select('*');

            if (error) {
                console.error(`❌ Erreur pour ${table}:`, error);
                backupData.tables[table] = { error: error.message };
            } else {
                backupData.tables[table] = data || [];
                console.log(`✅ ${table}: ${data?.length || 0} enregistrements`);
            }
        } catch (err) {
            console.error(`❌ Exception pour ${table}:`, err);
            backupData.tables[table] = { error: err.message };
        }
    }

    // Sauvegarder dans un fichier JSON
    const backupFile = path.join(__dirname, 'database-backup.json');
    fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2));
    
    console.log('✅ Export terminé:', backupFile);
    
    // Créer un résumé
    const summary = {
        date: backupData.timestamp,
        tables: Object.keys(backupData.tables).map(table => ({
            name: table,
            records: Array.isArray(backupData.tables[table]) ? backupData.tables[table].length : 0,
            status: backupData.tables[table].error ? 'error' : 'success'
        }))
    };
    
    fs.writeFileSync(path.join(__dirname, 'backup-summary.json'), JSON.stringify(summary, null, 2));
    console.log('📊 Résumé créé: backup-summary.json');
}

exportData().catch(console.error);
