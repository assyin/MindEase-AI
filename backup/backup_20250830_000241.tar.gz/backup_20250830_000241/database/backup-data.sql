-- Sauvegarde des données MindEase AI
-- Généré automatiquement

-- Export des profils utilisateurs
\copy (SELECT * FROM user_profiles) TO 'user_profiles_backup.csv' WITH CSV HEADER;

-- Export des programmes thérapeutiques
\copy (SELECT * FROM therapy_programs) TO 'therapy_programs_backup.csv' WITH CSV HEADER;

-- Export des sessions
\copy (SELECT * FROM therapy_sessions) TO 'therapy_sessions_backup.csv' WITH CSV HEADER;

-- Export des devoirs
\copy (SELECT * FROM homework_assignments) TO 'homework_assignments_backup.csv' WITH CSV HEADER;

-- Export des profils d'experts
\copy (SELECT * FROM expert_profiles) TO 'expert_profiles_backup.csv' WITH CSV HEADER;

-- Export des rapports de progrès
\copy (SELECT * FROM progress_reports) TO 'progress_reports_backup.csv' WITH CSV HEADER;
