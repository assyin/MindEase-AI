-- Restauration des données MindEase AI
-- ATTENTION: Supprime toutes les données existantes

BEGIN;

-- Vider les tables dans l'ordre (respecter les FK)
DELETE FROM progress_reports;
DELETE FROM homework_assignments;
DELETE FROM therapy_sessions;
DELETE FROM therapy_programs;
DELETE FROM expert_profiles;
DELETE FROM user_profiles;

-- Restaurer les données
\copy user_profiles FROM 'user_profiles_backup.csv' WITH CSV HEADER;
\copy expert_profiles FROM 'expert_profiles_backup.csv' WITH CSV HEADER;
\copy therapy_programs FROM 'therapy_programs_backup.csv' WITH CSV HEADER;
\copy therapy_sessions FROM 'therapy_sessions_backup.csv' WITH CSV HEADER;
\copy homework_assignments FROM 'homework_assignments_backup.csv' WITH CSV HEADER;
\copy progress_reports FROM 'progress_reports_backup.csv' WITH CSV HEADER;

COMMIT;
