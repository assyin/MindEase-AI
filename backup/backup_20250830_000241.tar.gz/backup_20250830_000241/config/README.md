# MindEase AI - راحة العقل

**Plateforme de soutien psychologique par IA avec système dual-engine (Gemini + OpenAI)**

## 🚀 Quick Start

